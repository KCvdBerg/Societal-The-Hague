# README File

Created by:
Group Number 3

Lotte Westrik Broeksma - 5109477  
Pepijn de Haan - 4956451  
Elisa Arts - 4780396  
Emily Chatziandreou - 4934679  
Lisa Trinh - 5100178


## Introduction
Hi there, 

Welcome to our folder (EPA133a-G3-A2) that contains all the details of 
Assignment 3 of Advanced Simulation. In this folder, you'll find 5 other
folders and 2 separate files. In this README file we'll discuss the 
contents of everything shortly. 


## README
The README file is the file you're reading at this exact moment. It tells 
the reader what the contents are of the other files that are included 
in the folder. If you're still interested in that information, continue reading. 


## Data 
In the 'Data' folder, there are three other folders. A 'Processed' one, a 'semi-processed one', and a 
'Raw' one. 

The 'Raw' map contains the data that we got when assigned
with this assignment. It has the 95% cleaned roads and 
bridges file (__roads3.csv_ and _BMMS_overview.xlsx_) that are cleaned 
by Alexander Verbraeck and his team. It also contains two additional files from the RMMS folder from assignment 1;
N1.widths.processed.txt and N2.widths.processed.txt, as well as the shapefiles containing the Bangladeshi waterways,
and the flood vulnerability.These files are cleaned and used 
in several notebooks, which will be discussed later.

The 'Processed' map contains the cleaned datafile final_cleaned_data.csv. This file comprises all of the roads
that intersect with the N1 or N2 that are longer than 25 km, as well as the (cleaned)
bridges present on those roads. The file is the product of five consecutive notebooks, 
which can be found in the 'notebook' folder. This extra cleaning process was needed because the raw bridges and roads 
file still had some errors that needed solving before they could be used 
in the simulation. Example of an error is that the LRP's of bridges were seen as 
separate/different bridges even though they were from the same bridge.
To use the bridge and road file in the simulation, this error had to
be solved.

The 'semi-processed' folder contains several files. The first two (possible_crossings_to_check.csv and 
intersections_to_check_final.csv) are the product of notebook 1. The 'probable_intersections_to_check_final.csv' 
and 'probable_crossings_extra.csv' files originates from notebook 2. 'identified_roads_final.csv' comes from notebook 3.
and 'cleaned_bridges_final.csv' from notebook 4. Notebook 5 is responsible for the multiple shapefiles, regarding
which areas have which level of flood vulnerability. 'bridges_vul_index' comes from notebook 6, and lastly 
'cleaned_data_final.csv' is the result of notebook 7.


## Model
The 'Model' folder contains four Python models: _model.py_, _components.py_, 
 _model_run.py_ and _model_viz.py_ and a 'Continuous Space' 
folder that we received for the visualisations of the model. The Python library
Mesa is used for simulation in these models. [Mesa](https://mesa.readthedocs.io/en/stable/)
allows users to quickly create agent-based models. 

The _model.py_ model contains code for the Model, or the 'grid' on
which the Agents move. Here, the grid gets defined: what is the 
size of the grid, how to Agents move to the next point on the grid
and what is their driving time? Functions from inter alia Mesa and the 
_components.py_ model are imported to make this model functional. 

The _components.py_ model contains code for the Agents in the model. 
Agents are individual 'beings' that have their own properties. The 
different Agents in the model are: Infrastructure (Bridges, Links,
SourceSinks) and Vehicles. In _components.py_, these Agents get
their definitions: how are they made, and how to they move/store data?
The _components.py_ model is imported into the _model.py_ model so that
the separate components from the _components.py_ model can be used in the 
whole Model.

``If you want to run the model, you should run this file (model_run.py)!`` 
_Model_run.py_ combines the information from _components.py_ and 
_model.py_ into a working simulation, and runs this. The different scenario's
that are defined for this Assignment are also in this file, so when you run
this file, you'll also run all the scenario's. The output of these 
scenario's can be found in folder 'Experiments'. 

'Model_viz.py' visualizes the simulation on an online browser tab.


## Notebooks
This folder contains several notebooks, used during the data cleaning process, 
analysis of the results of the experiments. The notebooks can be
run in the order that they have been given. 

Notebook 1 : 'Identify and clean roads and intersections' does exactly as the title states. 
The raw road data is loaded into the notebook, after which a selection is made of roads that 
are longer than 25 km. This notebook also identifies all of the intersections present on the N1
and N2, and matches these crossing roads to the roads that are longer than 25 km. The
remaining roads are extracted to the possible_crossings_to_check.csv
file and put in the semi-processed folder. If the coordinates of the crossing on N1/N2 did
not match to the same crossing on the sideroad, the coordinates on N1/N2 are held as benchmark.
This because we assume that the administration of the national roads are updated more frequently
than those of the regional roads. Here, a threshold of 1km distance is used. The intersection points
that fall inside of this threshold are extracted in the 'intersections_to_check_final.csv' file.

Notebook 2 : 'Check remaining crossings' - The resulting possible_crossings_to_check.csv file
from notebook 1 is used to visually identify if there are any more roads that cross the N1
or N2, but are not identified as a CrossRoad or SideRoad. The additional identified roads, 
are subjected to another analysis. For each point on that road, the distance is calculated to 
each point on the N1 and N2. With this and a maximum threshold distance of 1 km, five additional
roads have been found. These intersection points are extracted to the 'probable_intersections_to_check_final.csv' 
and 'probable_crossings_extra.csv' files. 

Notebook 3 : 'Inspection additional roads and create dataframe for simulation model' takes the 
'intersections_to_check_final.csv' from notebook 1, as well as the 'probable_intersections_to_check_final.csv' and
'probable_crossings_extra.csv' from notebook 2, to check if waterways (raw data = 'waterways.shp') disrupts the intersections. 
The resulting roads, including their start- and endpoint, as well as intersections are put in the 
'identified_roads_final.csv' file.

Notebook 4 : 'Handle duplicate bridges' ensures that no duplicate bridges are left in the 
final dataframe for the simulation. It used the BMMS_overview.xlsx and identified_roads_final.csv
files to make a selection of bridges that need cleaning. The first cleaning iteration is based
on LRPName and chainage; for each road, it is researched if there are bridges that have the 
same LRPName and chainge. If so, only one of them is kept (the one with the least missing values),
and the 'worse' bridge condition is kept. These steps are repeated for duplicate bridged 
based on latitude and longitude. As a last cleaning step, the amount of lanes the bridge has are 
added using the N1.width.processed.txt and N2.width.processed.txt as a guide.

Notebook 5 : 'Identify flood zones' used the flood vulnerability datasets to create shapefiles of 
Bangladesh, containing which areas are part of which category of vulnerability. The missing values 
of the vulnerability index are filled with the average value of its neighbours. The final identified
areas, are written out as seperate shapefiles.

Notebook 6 : 'Add vulnerability index to bridges' does exactly what the name suggest. For each of the cleaned
bridges, it is checked in which shapefile they are located, after which they get the corresponding category
in a new column. The output file 'bridges_vul_index.csv' contains all of the cleaned bridges on the identified
roads, along with how vulnerable their location is for floods, according to the dataset used in notebook 5. 

Notebook 7 : 'Final merge of the road and bridge datasets' merges the final road and bridge files,
generated in notebook 3 and 6 respectively, and prepares them for the simulation model. Between each
LRP (starting, intersection, bridge, endpoint), a link is added, in which the length
of that link is represented.


## Experiments 
In the 'Experiments' folder, there are 9 csv file's 'scenario0.csv', 'scenario1.csv'
et cetera that contains the output of the simulation per scenario: 
the average driving times of the goods trucks per replication. This data 
is used in _experiment_analysis_assignment3.ipynb_ to analyze the driving times of the trucks across the 
different scenario's. 


## Report
This folder contains a written report that explains what and why decisions
were made regarding the data and the models. The results that came from
the simulation are analyzed and a conclusion is formulated. This is all done
in line with the guidelines from [Assignment 3](https://brightspace.tudelft.nl/d2l/le/content/595868/viewContent/3335261/View).


## Requirements
This folder contains a file where all the required packages and libraries
are shown that need to be installed to run the simulation successfully.


Enjoy reading!  
Hasta la vista, Group 3
