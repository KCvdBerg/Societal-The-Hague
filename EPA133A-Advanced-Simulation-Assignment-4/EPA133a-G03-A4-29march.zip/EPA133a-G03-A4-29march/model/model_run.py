from model import BangladeshModel
import random
import pandas as pd

# ---------------------------------------------------------------
def RunExperiments(scenario, replications, runtime): # Runs per scenario
    """
    Function to run a simulation with the Bangladesh model
    for a given scenario and a number of replications.
    The results are collected in one dataframe.
    """

    # Create a dataframes for saving the results
    scenario_drive_data = pd.DataFrame(columns=['replication', 'avg_driving_time'])

    # To create the seeds randomly given x replications
    # If you want to replicate, change this to your own seeds for x amount of replications
    # You need a list of length x to create x replications
    seeds = [random.randint(1000000, 9999999) for _ in range(replications)]

    for replication_nr, seed in enumerate(seeds):
        sim_model = BangladeshModel(seed=seed, category_chances=scenario)
        for step in range(runtime):
            sim_model.step()

        # Extract the vehicle driving times from the model
        drive_data = sim_model.driving_times
        replication_drive_data = pd.DataFrame(drive_data, columns=['vehicle_id', 'driving_time'])
        avg_drive_data = replication_drive_data['driving_time'].mean()

        # Keep track of the number of replications
        replication = replication_nr + 1

        # Add average driving time with replication
        replication_average_drive_data = pd.DataFrame([[replication, avg_drive_data]], columns=['replication',
                                                                                                'avg_driving_time'])

        # Add the results from this replication to the scenario results
        scenario_drive_data = pd.concat([scenario_drive_data,replication_average_drive_data], ignore_index=True)

        # Show progress
        print("scenario {}, replication {} done".format(scenario, replication_nr + 1))

    return scenario_drive_data


# ---------------------------------------------------------------
'''Run the simulation in multiple scenarios for a set runtime
and number of replications. Save the results in csv files.'''

# Create a list of lists with each scenario (including scenario 0)
scenarios = [[0, 0, 0, 0], [0, 0, 0, 5], [0, 0, 5, 10], [0, 5, 10, 20], [5, 10, 20, 40]]

# Define the run time and the number of replications
run_length = 5 * 24 * 60
replications = 10

# Run the simulation for each scenario and save
for scenario_nr, scenario in enumerate(scenarios):
    scenario_drive_data = RunExperiments(scenario, replications, run_length)
    scenario_drive_data.to_csv('../experiment/scenario{}.csv'.format(scenario_nr), index=False)